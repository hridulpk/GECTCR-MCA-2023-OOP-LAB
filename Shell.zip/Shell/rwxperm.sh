echo "Files with rwx permission"
for file in * ;
do

