echo "The no.of files:"
ls -l | grep "^-" | wc -l
